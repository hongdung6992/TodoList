<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '123123');
define('DB_NAME', 'todo_list');

define('DS', DIRECTORY_SEPARATOR);
define('ROOT_URL', 'http://' . $_SERVER['HTTP_HOST'] . DS . 'TodoList');

