<link rel="stylesheet" href="<?php echo ROOT_URL . DS ?>public/plugins/fontawesome-free/css/all.min.css">
<link rel="stylesheet" href="<?php echo ROOT_URL . DS ?>public/dist/css/adminlte.min.css">
<link rel="stylesheet" href="<?php echo ROOT_URL . DS ?>public/plugins/daterangepicker/daterangepicker.css">
<link rel="stylesheet" href="<?php echo ROOT_URL . DS ?>public/plugins/toastr/toastr.min.css">
<link rel="stylesheet" href="<?php echo ROOT_URL . DS ?>public/dist/css/main.css">