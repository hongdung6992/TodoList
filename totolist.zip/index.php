<?php
  session_start();
  require_once './app/Bridge.php';
  require_once './config.php';
  require_once './app/helpers.php';
  $myApp = new App;

?>